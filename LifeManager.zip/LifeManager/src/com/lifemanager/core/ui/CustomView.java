package com.lifemanager.core.ui;

import android.view.View;

public interface CustomView {

	public void setOppositeView(View v);

	public void setContent(View v);
	
	public void setTouchMode(int i);

}
