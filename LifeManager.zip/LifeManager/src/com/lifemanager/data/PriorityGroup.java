
package com.lifemanager.data;

public class PriorityGroup implements TaskGroup {

    private final int _GruopIndex;
    private int _Count;
    private int _FirstTaskIndex;
    private int _Text;
    private int _IconImageRes;

    public PriorityGroup(int index) {
        _GruopIndex = index;
    }

    public void buildGroup(int first, int end) {
        _FirstTaskIndex = first;
        _Count = (end - first) > 0 ? end - first + 1 : 0;
    }

    @Override
    public int getGruopID() {
        return _GruopIndex;
    }

    @Override
    public int getCount() {

        return 0;
    }

    @Override
    public int getFirstTaskIndex() {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public String getText() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int getIconImageRes() {
        // TODO Auto-generated method stub
        return 0;
    }

}
