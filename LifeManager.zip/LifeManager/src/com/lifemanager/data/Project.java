
package com.lifemanager.data;

public interface Project {

}
