
package com.lifemanager.exception;

public class NotImplementException extends Exception {

    private static final long serialVersionUID = 9192797323093142453L;

    public NotImplementException() {
        super("Function Not Implement Yet.");
    }

}
