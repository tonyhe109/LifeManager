package com.lifemanager.improve;

import com.lifemanager.LifeManagerModule;

public class UserActionCollector {
	
	public static void activityOnCreate(LifeManagerModule module){
		
	}

}
