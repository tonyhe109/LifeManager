package com.lifemanager.improve;

public interface Collector {
	
	public void ActivityOnCreat();

}
