package com.lifemanager.ui.view;

import android.content.Context;
import android.view.View;

public class PriorityTaskView extends View{
	
	public PriorityTaskView(Context context) {
		super(context);
	}

}
