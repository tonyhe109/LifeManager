
package com.lifemanager.ui.data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.lifemanager.data.Task;
import com.lifemanager.data.TaskList;
import com.lifemanager.exception.NotImplementException;

/**
 * @author tony.he
 * @param <TaskViewItem>
 */
public abstract class TaskArrayAdapter<TaskViewItem> extends BaseAdapter {

    public static final int ORDER_PRIORITY = 0;
    public static final int ORDER_TIME = 1;

    public static final int MODE_SIMPLE = 0;
    public static final int MODE_DETAILS = 1;

    protected TaskList _TaskList = null;
    protected int _Order = ORDER_PRIORITY;
    protected int _Mode = MODE_SIMPLE;
    protected List<TaskViewItem> _AllTaskItems;
    protected Object _Lock = new Object();

    protected ArrayList<TaskViewItem> _OriginalItems;
    // TODO add task fillter , as the task have many status ...

    /**
     * Indicates whether or not {@link #notifyDataSetChanged()} must be called
     * whenever {@link #_AllTaskItems} is modified.
     */
    private boolean _NotifyOnChange = true;

    public TaskArrayAdapter(TaskList tList) {
        _TaskList = tList;
        invalidate();
    }

    public TaskArrayAdapter(TaskList tList, int order, int mode) {
        _Order = order;
        _TaskList = tList;
        invalidate();
    }

    public void setTaskList(TaskList tList) {
        _TaskList = tList;
        invalidate();
    }

    public void setOrder(int order) {
        if (order != ORDER_PRIORITY && order != ORDER_TIME) {
            throw new IllegalStateException("Task Item List have no such order mode");
        }
        if (_Order != order) {
            _Order = order;
        }
        invalidate();
    }

    public void setMode(int mode) {
        if (mode != MODE_SIMPLE && mode != MODE_DETAILS) {
            throw new IllegalStateException("Task Item List have no such order mode");
        }
        if (_Mode != mode) {
            _Mode = mode;
        }
        invalidate();
    }

    public int size() {
        return _AllTaskItems.size();
    }

    /**
     * Adds the specified object at the end of the array.
     * 
     * @param object The object to add at the end of the array.
     */
    public void add(Task task) {
        insert(task, size());
    }

    /**
     * Adds the specified items at the end of the array.
     * 
     * @param items The items to add at the end of the array.
     */
    public void addAll(Task... tasks) {
        synchronized (_Lock) {
            new NotImplementException().printStackTrace();
        }
        if (_NotifyOnChange)
            notifyDataSetChanged();
    }

    /**
     * Inserts the specified object at the specified index in the array.
     * 
     * @param object The object to insert into the array.
     */
    private void insert(Task task, int index) {
        synchronized (_Lock) {
            new NotImplementException().printStackTrace();
        }
        if (_NotifyOnChange)
            notifyDataSetChanged();
    }

    /**
     * Removes the task from the array.
     * 
     * @param Task The task to remove.
     */
    public void remove(Task task) {
        synchronized (_Lock) {
            _AllTaskItems.remove(indexOf(task));
        }
        if (_NotifyOnChange)
            notifyDataSetChanged();
    }

    protected int indexOf(Task task) {
        synchronized (_Lock) {
            int index = -1;
            int size = _AllTaskItems.size();
            for (int i = 0; i < size; i++) {
                TaskViewItem item = _AllTaskItems.get(i);
                if (item instanceof TaskItem && ((TaskItem) item).getData().equals(task)) {
                    index = i;
                    break;
                }
            }
            return index;
        }
    }

    protected int indexOf(TaskViewItem item) {
        int index = -1;
        new NotImplementException().printStackTrace();
        return index;
    }

    /**
     * Remove all elements from the list.
     */
    public void clear() {
        synchronized (_Lock) {
            _AllTaskItems.clear();
        }
        if (_NotifyOnChange)
            notifyDataSetChanged();
    }

    protected abstract void invalidate();

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        _NotifyOnChange = true;
    }

    @Override
    public int getCount() {
        return size();
    }

    @Override
    public TaskViewItem getItem(int position) {
        return _AllTaskItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public abstract View getView(int position, View convertView, ViewGroup parent);

}
