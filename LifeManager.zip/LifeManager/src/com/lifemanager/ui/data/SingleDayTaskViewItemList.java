
package com.lifemanager.ui.data;

import com.lifemanager.data.TaskList;

public class SingleDayTaskViewItemList<TaskViewItem> extends TaskViewItemList {

    public SingleDayTaskViewItemList(TaskList tList) {
        super(tList);
    }

    @Override
    protected void invalidate() {
       

    }

}
