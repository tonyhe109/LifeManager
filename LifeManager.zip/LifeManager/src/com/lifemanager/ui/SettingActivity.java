package com.lifemanager.ui;

import android.support.v4.app.FragmentActivity;

public class SettingActivity extends FragmentActivity {

}
